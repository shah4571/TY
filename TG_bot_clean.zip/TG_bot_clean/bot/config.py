# ==============================

#        TELEGRAM API

# ==============================

API_ID = 28751385

API_HASH = "17749fb0142983c9f5979e185aa9fd27"

BOT_TOKEN = "8122704675:AAGpJqkTRg6m5uR4PwUMhH28u7wIavjNDRw"



# ==============================

#          CHANNELS

# ==============================

CHANNEL_SUBMIT = -10030456756701          # Verified sessions delivery

CHANNEL_VERIFIED = -1002541140420        # Active/verified session report

CHANNEL_REJECTED = -1002562141472        # Rejected sessions report

CHANNEL_WITHDRAW_REPORT = -1003047983465 # Withdraw request report



# ==============================

#            ADMIN

# ==============================

ADMIN_ID = 8046164230



# ==============================

#           SECURITY



# ==============================

#        CURRENCY RATES

# ==============================

USD_TO_TRX = 57.0

USD_TO_BKASH = 108.0

USD_TO_USDT_BEP20 = 1.0